# Readme - Preparation and Running This Code

## Customer Segmentation Project

### A light EDA piece

#### Setup:

1. You will need to have `numpy`, `pandas`, `seaborn`, and `matplotlib`.

2. The data set is from Kaggle and can be downloaded from this repo.

#### That is all, I hope you enjoy!

My other projects can be found at my [GitHub](https://github.com/rileypredum).

I also write about them on [Medium](https://medium.com/@rileypredum).
